// Content Script injected into https://infolookupp.com/ AND https://infolookup.site/
// Runs concurrently inside persistent headless background iframes

(function () {
  // Only execute when running inside an embedded iframe (background automation)
  if (window.self === window.top) {
    return;
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const host = window.location.hostname.toLowerCase();

  // The host decides which search flow runs, and both flows report under the name of the site
  // they scraped - that name is the record key the widget hangs its card, ZIP filter and DOB run
  // on, so it has to match the key the background dispatches with (`worker-<source>`).
  //
  // The match is by exact host on purpose: `infolookupp.com` contains the string "infolookup",
  // so the old `host.includes('infolookup') ? 'infolookup.site' : 'vibegenx.com'` classified the
  // second source as infolookup.site and ran the wrong flow, with the wrong selectors, against it.
  const SOURCE_BY_HOST = {
    'infolookup.site': 'infolookup.site',
    'www.infolookup.site': 'infolookup.site',
    'infolookupp.com': 'infolookupp.com',
    'www.infolookupp.com': 'infolookupp.com',
    'uspeoplesearch.net': 'uspeoplesearch.net',
    'www.uspeoplesearch.net': 'uspeoplesearch.net'
  };
  const sourceName = SOURCE_BY_HOST[host] || 'infolookup.site';

  let port = null;
  let activeSearchId = null;

  function connectPort() {
    try {
      port = chrome.runtime.connect({ name: 'worker-' + sourceName });

      port.onMessage.addListener(async (msg) => {
        if (msg.action === 'EXECUTE_SEARCH') {
          activeSearchId = msg.searchId;
          if (sourceName === 'infolookup.site') {
            await executeInfolookupSearch(msg.phone, msg.searchId);
          } else if (sourceName === 'uspeoplesearch.net') {
            await executeUsPeopleSearch(msg.phone, msg.searchId);
          } else {
            await executeInfolookuppSearch(msg.phone, msg.searchId);
          }
        }
      });

      port.onDisconnect.addListener(() => {
        port = null;
        setTimeout(connectPort, 1200);
      });

      port.postMessage({ action: 'WORKER_READY', source: sourceName });
    } catch (e) {
      setTimeout(connectPort, 1500);
    }
  }

  connectPort();

  /* ═══════════════════════════════════════════════════════
     INFOLOOKUP.SITE HELPERS
  ═══════════════════════════════════════════════════════ */

  // infolookup.site refuses to look the same number up twice and shows
  // "This number was just searched. Please try a different number."
  //
  // The check is `phoneRaw === lastSearchedNumber`, where the site declares
  // `let lastSearchedNumber = ''` at the top level of a classic <script>. That binding lives in the
  // page's global *lexical* environment, so `window.lastSearchedNumber = ''` only creates a stray
  // property on the window object and never touches the real variable. Injected <script> elements
  // run in the page's main world, where a bare assignment resolves the real binding.
  // Returns true when the site's guard variable was actually reset.
  function resetInfolookupDuplicateGuard() {
    const marker = 'data-dnc-guard-reset';
    try {
      document.documentElement.removeAttribute(marker);
    } catch (e) {}

    try {
      const resetScript = document.createElement('script');
      resetScript.textContent =
        '(function(){' +
        'var ok=false;' +
        'try{ lastSearchedNumber = ""; ok = (lastSearchedNumber === ""); }catch(e){}' +
        'if(!ok){ try{ eval("lastSearchedNumber = \\"\\""); ok = (lastSearchedNumber === ""); }catch(e){} }' +
        'try{ document.documentElement.setAttribute("' + marker + '", ok ? "1" : "0"); }catch(e){}' +
        '})();';
      document.documentElement.appendChild(resetScript);
      resetScript.remove();
    } catch (e) {}

    return document.documentElement.getAttribute(marker) === '1';
  }

  // Wipes the rendered result so a fresh lookup can't be confused with stale data.
  function clearInfolookupResultsDom() {
    try {
      const dnc = document.getElementById('dncStatus');
      if (dnc) dnc.textContent = '—';
      const lit = document.getElementById('litigator');
      if (lit) lit.textContent = '—';
      const black = document.getElementById('blacklist');
      if (black) black.textContent = '—';
      const list = document.getElementById('personInfoListContainer');
      if (list) list.innerHTML = '';
      const errorDiv = document.getElementById('error');
      if (errorDiv) {
        errorDiv.style.display = 'none';
        const errorMsg = document.getElementById('errorMessage');
        if (errorMsg) errorMsg.textContent = '';
      }
    } catch (e) {}
  }

  // Reads whatever result infolookup.site currently has rendered.
  // `ready` is false while the compliance cells are still loading.
  function readInfolookupDomState() {
    const dncEl = document.getElementById('dncStatus');
    const litEl = document.getElementById('litigator');
    const blackEl = document.getElementById('blacklist');

    const dncText = dncEl ? dncEl.textContent.trim() : '';
    const litText = litEl ? litEl.textContent.trim() : '';
    const blackText = blackEl ? blackEl.textContent.trim() : '';

    const isLoading = (el, txt) =>
      !txt || txt === '—' || txt.toLowerCase().includes('load') || !!el?.querySelector('.loading-indicator');

    const complianceReady = !isLoading(dncEl, dncText) && !isLoading(litEl, litText) && !isLoading(blackEl, blackText);

    let personReady = false;
    let persons = [];
    const listContainer = document.getElementById('personInfoListContainer');
    const firstSection = listContainer?.querySelector('.section') || listContainer?.querySelector('.person-info');
    const personNameEl = firstSection?.querySelector('.person-name');
    const personNameText = personNameEl ? personNameEl.textContent.trim() : '';
    const noResult = /no result found for this number|no owner information available/i.test(
      firstSection?.textContent || ''
    );
    if (personNameText && !personNameText.toLowerCase().includes('load')) {
      personReady = true;
      const lowerName = personNameText.toLowerCase();
      persons = lowerName.includes('no result') || lowerName.includes('no owner')
        ? []
        : extractInfolookupSitePersons();
    }

    return {
      ready: complianceReady,
      personReady,
      persons,
      noResult,
      compliance: complianceReady
        ? {
            dnc: formatInfolookupComplianceValue(cleanText(dncText)),
            litigator: formatInfolookupComplianceValue(cleanText(litText)),
            blacklist: formatInfolookupComplianceValue(cleanText(blackText))
          }
        : null
    };
  }

  function postInfolookupResult(searchId, compliance, persons) {
    if (!port) return;
    const list = persons || [];
    port.postMessage({
      action: 'SEARCH_RESULT',
      searchId: searchId,
      source: 'infolookup.site',
      data: {
        ...compliance,
        persons: list,
        person: list[0] || null
      }
    });
  }


  /* ═══════════════════════════════════════════════════════
     SOURCE 1: INFOLOOKUP.SITE FAST SEARCH (NO RELOAD)
  ═══════════════════════════════════════════════════════ */
  async function executeInfolookupSearch(phone, searchId) {
    const start = Date.now();
    let phoneInput = null;

    // Wait for #phoneInput (already present 99% of the time)
    while (Date.now() - start < 8000) {
      phoneInput = document.getElementById('phoneInput') || document.querySelector('input[type="tel"]');
      if (phoneInput) break;
      await sleep(150);
    }

    if (!phoneInput) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: 'infolookup.site',
          error: 'Phone input (#phoneInput) not found.'
        });
      }
      return;
    }

    // infolookup.site blocks searching the same number twice ("This number was just searched"),
    // so clear that guard first — otherwise repeat lookups abort before any data is rendered.
    const guardCleared = resetInfolookupDuplicateGuard();

    // Clear previous results in DOM before executing new search to avoid reading stale data.
    // This is only safe when the guard was cleared, because that guarantees a fresh lookup will run
    // and repopulate the DOM. If the guard could not be cleared we deliberately leave the DOM intact
    // so the duplicate-search fallback further down still has the site's own data to read.
    if (guardCleared) {
      clearInfolookupResultsDom();
    }
    const personResultStamp = () => {
      const list = document.getElementById('personInfoListContainer');
      return list ? (list.textContent || '').replace(/\s+/g, ' ').trim() : '';
    };
    const personResultStampBefore = personResultStamp();

    // 1. Enter phone number
    const cleanDigits = phone.replace(/\D/g, '');

    // 2. Find the search button
    const searchBtn = document.getElementById('searchButton') || document.querySelector('button#searchButton');
    if (!searchBtn) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: 'infolookup.site',
          error: 'Search button (#searchButton) not found.'
        });
      }
      return;
    }

    // Fills the input and triggers the site's own search handler.
    // Reusable so a retry after a duplicate-guard hit can re-submit the same number.
    function submitSearch() {
      phoneInput.focus();
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) {
        nativeSetter.call(phoneInput, cleanDigits);
      } else {
        phoneInput.value = cleanDigits;
      }
      phoneInput.dispatchEvent(new Event('input', { bubbles: true }));
      phoneInput.dispatchEvent(new Event('change', { bubbles: true }));
      phoneInput.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

      try {
        phoneInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      } catch (e) {}
      searchBtn.click();
    }

    await sleep(60);
    submitSearch();

    // 3. Fast-poll for new results (100ms interval for sub-second capture)
    const searchStart = Date.now();
    const maxWaitResults = 45000;
    let compliance = null;
    let duplicateRetries = 0;
    let stableResultKey = '';
    let stableResultAt = 0;

    while (Date.now() - searchStart < maxWaitResults) {
      if (activeSearchId !== searchId) return; // Discard if user triggered a newer search

      // Check if site returned an error
      const errorDiv = document.getElementById('error');
      const errorMsg = document.getElementById('errorMessage');
      if (errorDiv && errorDiv.style.display !== 'none') {
        const errText = errorMsg?.textContent.trim() || errorDiv.textContent.trim();
        const errLower = errText ? errText.toLowerCase() : '';
        if (errText && !errLower.includes('looking up')) {
          if (errLower.includes('just searched')) {
            // Duplicate-search guard tripped. The site aborts the new lookup but deliberately keeps
            // #resultsContainer visible, so the data for this exact number is still on screen.
            if (guardCleared) {
              // A fresh lookup was expected, so the DOM is empty — force the guard off and retry once.
              if (duplicateRetries === 0) {
                duplicateRetries++;
                resetInfolookupDuplicateGuard();
                clearInfolookupResultsDom();
                submitSearch();
                continue;
              }
            } else {
              // The guard could not be cleared, but the result left on screen is this number's result.
              const dupState = readInfolookupDomState();
              if (dupState.ready) {
                postInfolookupResult(searchId, dupState.compliance, dupState.persons);
                return;
              }
            }
          }

          if (port) {
            port.postMessage({
              action: 'SEARCH_RESULT',
              searchId: searchId,
              source: 'infolookup.site',
              error: errText
            });
          }
          return;
        }
      }

      // Check compliance stats + person information
      const state = readInfolookupDomState();

      if (state.ready) compliance = state.compliance;

      const personReady = state.personReady;
      const personsList = state.persons;

      const freshPersonResult =
        guardCleared || personResultStamp() !== personResultStampBefore;
      if (state.noResult && freshPersonResult) {
        postInfolookupResult(
          searchId,
          compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' },
          []
        );
        return;
      }

      if (personsList.length > 0 && personReady && freshPersonResult) {
        const resultKey = JSON.stringify({ persons: personsList, compliance });
        if (resultKey !== stableResultKey) {
          stableResultKey = resultKey;
          stableResultAt = Date.now();
        } else if (
          Date.now() - stableResultAt >= 1200 &&
          (state.ready || Date.now() - stableResultAt >= 3000)
        ) {
          postInfolookupResult(
            searchId,
            compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' },
            personsList
          );
          return;
        }
      }

      await sleep(100);
    }

    // Fallback if loop ends
    const finalState = readInfolookupDomState();
    const finalPersons = finalState.persons;
    const finalPersonResultIsFresh =
      guardCleared || personResultStamp() !== personResultStampBefore;
    if (
      (finalPersons.length > 0 && finalPersonResultIsFresh) ||
      (finalState.noResult && finalPersonResultIsFresh)
    ) {
      postInfolookupResult(
        searchId,
        compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' },
        finalPersons
      );
      return;
    }

    if (port) {
      port.postMessage({
        action: 'SEARCH_RESULT',
        searchId: searchId,
        source: 'infolookup.site',
        error: 'Timed out waiting for infolookup.site results.'
      });
    }
  }

  function cleanAddressField(val) {
    if (!val) return '';
    const cleaned = val.replace(/\s+/g, ' ').trim();
    const lower = cleaned.toLowerCase();
    if (
      lower === 'unknown' ||
      lower === 'n/a' ||
      lower === 'none' ||
      lower === '-' ||
      lower === '—' ||
      lower === 'null' ||
      lower === 'undefined' ||
      lower.includes('no address') ||
      lower.includes('not listed') ||
      lower.includes('no record')
    ) {
      return '';
    }
    return cleaned;
  }

  // The "STATE / ZIP" column of a `.cx-addr-row` as two fields. Every shape the column has
  // been seen in is accepted: "TX 77047", "TX, 77047", "TX-77047", "Texas 77047", a bare
  // "77047" and a bare "TX". A dash placeholder cleans to nothing, so a row without a
  // location stays street-only.
  function splitStateZip(value) {
    const text = cleanAddressField(value);
    if (!text) return { state: '', zip: '' };

    const zipMatch = text.match(/(\d{5})(?:-\d{4})?\s*$/);
    const zip = zipMatch ? zipMatch[1] : '';
    const state = cleanAddressField(
      text
        .replace(/(\d{5})(?:-\d{4})?\s*$/, '')
        .replace(/[,\-|/]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
    );

    return { state, zip };
  }

  function extractInfolookupSitePersons() {
    const listContainer = document.getElementById('personInfoListContainer');
    if (!listContainer) return [];

    // Select only top-level person sections to avoid picking up nested .person-info elements
    let sections = Array.from(listContainer.querySelectorAll(':scope > .section'));
    if (sections.length === 0) {
      // Filter out elements whose parent or ancestor is already a .section
      sections = Array.from(listContainer.querySelectorAll('.section')).filter(
        (el) => !el.parentElement || !el.parentElement.closest('.section')
      );
    }
    if (sections.length === 0) {
      sections = Array.from(listContainer.querySelectorAll('.person-info, .card')).filter(
        (el) => !el.closest('.section')
      );
    }
    if (sections.length === 0 && listContainer.children.length > 0) {
      sections = Array.from(listContainer.children).filter((el) => el.nodeType === 1);
    }

    const persons = [];
    const seenCards = new Set();

    for (const sec of sections) {
      const nameEl = sec.querySelector('.person-name');
      const name = nameEl ? nameEl.textContent.replace(/\s+/g, ' ').trim() : '';
      if (!name || name.toLowerCase().includes('load') || name.toLowerCase().includes('no result') || name.toLowerCase().includes('no owner')) {
        continue;
      }

      let avatar = sec.querySelector('.person-avatar')?.textContent.trim() || '';
      if (!avatar || avatar.length > 3 || avatar.toLowerCase().includes('fa-') || avatar === 'LO') {
        avatar = name.slice(0, 2).toUpperCase();
      }

      const age = sec.querySelector('.person-age-display')?.textContent.replace(/\s+/g, ' ').trim() || '';

      // Scan all table rows across the card for the best address and full address history
      let bestAddress = null;
      let partialAddress = null;
      const allAddresses = [];
      const seenAddrKeys = new Set();

      function addAddressRecord(street, city, state, zip, rawFull) {
        street = cleanAddressField(street);
        city = cleanAddressField(city);
        state = cleanAddressField(state);
        zip = cleanAddressField(zip);

        const cityStateZip = [city, state].filter(Boolean).join(', ') + (zip ? ` ${zip}` : '');
        const full = rawFull ? cleanAddressField(rawFull) : [street, cityStateZip].filter(Boolean).join(', ');

        if (!street && !city && !zip) return;

        const dedupeKey = `${street.toLowerCase().replace(/[^a-z0-9]/g, '')}|${zip || city.toLowerCase()}`;
        if (seenAddrKeys.has(dedupeKey)) return;
        seenAddrKeys.add(dedupeKey);

        const addrObj = { street, city, state, zip, full };
        allAddresses.push(addrObj);

        if (street && cityStateZip && !bestAddress) {
          bestAddress = addrObj;
        } else if (street && !bestAddress) {
          bestAddress = addrObj;
        } else if (cityStateZip && !partialAddress) {
          partialAddress = addrObj;
        }
      }

      const rows = Array.from(sec.querySelectorAll('.address-table tbody tr, .address-table tr, table tbody tr, table tr'));
      for (const row of rows) {
        if (row.querySelector('th') || row.classList.contains('header')) continue;
        const rowLower = row.textContent.toLowerCase();
        if (rowLower.includes('lives at') && rowLower.includes('city')) continue;
        if (rowLower.includes('no address') || rowLower.includes('loading')) continue;

        const tds = Array.from(row.querySelectorAll('td'));
        if (tds.length >= 4) {
          addAddressRecord(tds[0].textContent, tds[1].textContent, tds[2].textContent, tds[3].textContent);
        } else if (tds.length === 3) {
          addAddressRecord(tds[0].textContent, tds[1].textContent, '', tds[2].textContent);
        } else if (tds.length === 2) {
          const val = cleanAddressField(tds[1].textContent || tds[0].textContent);
          const m = val.match(/^(.*?)[,\n]+([^,\n]+)[,\n\s]+([A-Za-z]{2}|[A-Za-z\s]+)(?:[,\s]+(\d{5}))?/);
          if (m) {
            addAddressRecord(m[1], m[2], m[3], m[4] || '', val);
          } else if (val) {
            addAddressRecord(val, '', '', '', val);
          }
        } else if (tds.length >= 1) {
          const val = cleanAddressField(tds[tds.length - 1].textContent);
          const m = val.match(/^(.*?)[,\n]+([^,\n]+)[,\n\s]+([A-Za-z]{2}|[A-Za-z\s]+)(?:[,\s]+(\d{5}))?/);
          if (m) {
            addAddressRecord(m[1], m[2], m[3], m[4] || '', val);
          } else if (val) {
            addAddressRecord(val, '', '', '', val);
          }
        }
      }

      let address = bestAddress || partialAddress;
      if (!address && allAddresses.length > 0) address = allAddresses[0];

      // Fallback: check other address elements if table yielded no address
      if (!address) {
        const addrBlock = sec.querySelector('.address, .person-address, .location, .addr, .address-line');
        if (addrBlock) {
          const txt = cleanAddressField(addrBlock.textContent);
          if (txt) {
            address = { street: txt, full: txt };
            addAddressRecord(txt, '', '', '', txt);
          }
        }
      }

      if (address && allAddresses.length === 0) {
        allAddresses.push(address);
      }

      // Deduplicate exact same person cards
      const dedupeKey = `${name.toLowerCase()}|${age.toLowerCase()}|${address?.full || ''}`;
      if (seenCards.has(dedupeKey)) {
        continue;
      }
      seenCards.add(dedupeKey);

      persons.push({ name, avatar, age, address, allAddresses });
    }

    return persons;
  }

  function extractInfolookupSitePerson() {
    const all = extractInfolookupSitePersons();
    return all && all.length > 0 ? all[0] : null;
  }

  function formatInfolookupComplianceValue(val) {
    if (!val) return 'Clean';
    const lower = val.toLowerCase().trim();
    if (lower === 'clean' || lower === 'not listed' || lower.includes('no record') || lower === 'no') {
      return 'Clean';
    }
    if (lower.includes('federal') && lower.includes('state')) {
      return 'Federal & State DNC';
    }
    if (lower.includes('federal')) {
      return 'Federal DNC';
    }
    if (lower.includes('state')) {
      return 'State DNC';
    }
    if (lower === 'listed' || lower === 'yes') {
      return 'Listed';
    }
    return val.replace(/\b\w/g, c => c.toUpperCase());
  }

  /* ═══════════════════════════════════════════════════════
     SOURCE 2: INFOLOOKUPP.COM FAST SEARCH (NO RELOAD)
  ═══════════════════════════════════════════════════════ */
  async function executeInfolookuppSearch(phone, searchId) {
    const start = Date.now();
    let phoneInput = null;

    // The search box is `input[type="tel"]` inside `.search-input-wrap` on the current build
    // (with a "Paste" button beside it); the older build had the same input without the wrapper,
    // so both shapes are accepted.
    while (Date.now() - start < 8000) {
      phoneInput =
        document.querySelector('.search-input-wrap input[type="tel"]') ||
        document.querySelector('input[type="tel"]') ||
        document.querySelector('input[inputmode="numeric"]') ||
        document.querySelector('input[placeholder*="555"]') ||
        document.querySelector('input[maxlength="14"]');

      if (phoneInput) break;
      await sleep(150);
    }

    if (!phoneInput) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: sourceName,
          error: 'Phone input field was not found on infolookupp.com.'
        });
      }
      return;
    }

    const cleanDigits = phone.replace(/\D/g, '');
    phoneInput.focus();
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(phoneInput, cleanDigits);
    } else {
      phoneInput.value = cleanDigits;
    }
    phoneInput.dispatchEvent(new Event('input', { bubbles: true }));
    phoneInput.dispatchEvent(new Event('change', { bubbles: true }));
    phoneInput.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

    await sleep(60);

    // The control that submits the search, in every shape this build has had: an id, a submit
    // button, a class that says "search", or a button whose label says "search". The current
    // build renders the search row as `.search-input-wrap` (input + a "Paste" button), so the
    // tag/class shapes are what actually find it there.
    const findSearchButton = () => {
      const byId = document.getElementById('search-btn') || document.getElementById('searchButton');
      if (byId) return byId;

      const byType = document.querySelector('button[type="submit"], input[type="submit"]');
      if (byType) return byType;

      // A class that says "search" - but never a search-clear/reset control, which sits in the
      // same row as the input.
      const byClass = Array.from(document.querySelectorAll('button.search-btn, button.search-submit, button[class*="search-"]')).find(
        (b) => !b.classList.contains('paste-clear-btn') && !/\b(clear|paste|reset)\b/i.test((b.textContent || '').trim())
      );
      if (byClass) return byClass;

      return (
        Array.from(document.querySelectorAll('button')).find((b) => {
          const label = (b.textContent || '').trim().toLowerCase();
          if (!label.includes('search')) return false;
          // The "Paste" / "Clear" control sits in the same row and must never be the submit.
          if (b.classList.contains('paste-clear-btn') || label.includes('paste')) return false;
          return true;
        }) || null
      );
    };

    let searchBtn = findSearchButton();
    for (let attempt = 0; attempt < 10 && !searchBtn; attempt++) {
      await sleep(150);
      searchBtn = findSearchButton();
    }

    const resultStampBefore = JSON.stringify({
      compliance: extractInfolookuppCompliance(),
      persons: extractInfolookuppPersons(),
      notFound: (document.querySelector('.cx-prompt.cx-not-found, p.cx-not-found') || {}).textContent || ''
    });

    // Enter is pressed as well: the older build needed it next to the click, and a build that
    // renders no submit button searches on Enter alone. A missing button is therefore not an
    // immediate error any more - the results wait below reports a timeout if nothing was ever
    // submitted, which is the honest answer for both builds.
    try {
      phoneInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    } catch (e) {}

    if (searchBtn) {
      searchBtn.click();
    } else {
      try {
        const form = phoneInput.form || (phoneInput.closest && phoneInput.closest('form'));
        if (form && typeof form.requestSubmit === 'function') {
          form.requestSubmit();
        }
      } catch (e) {}
    }

    const maxWaitResults = 45000;
    const searchStartTime = Date.now();
    let sawLoading = false;
    let stableResultKey = '';
    let stableResultAt = 0;

    await sleep(80);

    while (Date.now() - searchStartTime < maxWaitResults) {
      if (activeSearchId !== searchId) return;

      const bodyText = document.body.innerText || '';

      // Compliance and owners as the current build renders them: the pills sit in
      // `.compliance-status-item` (a `.compliance-label` next to a `.status-pill`) and the owners
      // in `.cx-cards .cx-card`, each with `.cx-addr-street` / `.cx-addr-city` /
      // `.cx-addr-statezip` rows.
      const compliance = extractInfolookuppCompliance();
      const personsList = extractInfolookuppPersons();
      const person = personsList[0] || null;
      const stillScrubbing = bodyText.includes('Running TCPA scrub') || bodyText.toLowerCase().includes('scrubbing');
      if (stillScrubbing) sawLoading = true;
      const notFoundEl = document.querySelector('.cx-prompt.cx-not-found, p.cx-not-found');
      const noResult =
        !!notFoundEl ||
        /no owner found for this number|no records found|invalid phone number/i.test(
          notFoundEl ? notFoundEl.textContent || '' : bodyText
        );
      const freshResult =
        sawLoading ||
        JSON.stringify({
          compliance,
          persons: personsList,
          notFound: notFoundEl ? notFoundEl.textContent || '' : ''
        }) !== resultStampBefore;

      if (noResult && freshResult) {
        if (port) {
          port.postMessage({
            action: 'SEARCH_RESULT',
            searchId: searchId,
            source: sourceName,
            data: {
              ...(compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
              persons: [],
              person: null,
              notFound: true
            }
          });
        }
        return;
      }

      if (compliance && compliance.dnc && compliance.litigator && compliance.blacklist && !stillScrubbing) {
        const isNotPlaceholder =
          !compliance.dnc.toLowerCase().includes('scrub') &&
          !compliance.litigator.toLowerCase().includes('scrub') &&
          !compliance.blacklist.toLowerCase().includes('scrub');

        if (isNotPlaceholder) {
          if (personsList.length > 0 && personsList[0].name && freshResult) {
            const resultKey = JSON.stringify({ compliance, personsList });
            if (resultKey !== stableResultKey) {
              stableResultKey = resultKey;
              stableResultAt = Date.now();
            } else if (Date.now() - stableResultAt >= 1200) {
              if (port) {
                port.postMessage({
                  action: 'SEARCH_RESULT',
                  searchId: searchId,
                  source: sourceName,
                  data: {
                    ...compliance,
                    persons: personsList,
                    person: person
                  }
                });
              }
              return;
            }
          }
        }
      }

      await sleep(100);
    }

    const finalCompliance = extractInfolookuppCompliance();
    const finalPersons = extractInfolookuppPersons();

    const finalNotFoundEl = document.querySelector('.cx-prompt.cx-not-found, p.cx-not-found');
    const finalNoResult =
      !!finalNotFoundEl ||
      /no owner found for this number|no records found|invalid phone number/i.test(
        finalNotFoundEl ? finalNotFoundEl.textContent || '' : (document.body.innerText || '')
      );
    const finalResultStamp = JSON.stringify({
      compliance: finalCompliance,
      persons: finalPersons,
      notFound: finalNotFoundEl ? finalNotFoundEl.textContent || '' : ''
    });
    if (
      (finalPersons.length > 0 || finalNoResult) &&
      (sawLoading || finalResultStamp !== resultStampBefore)
    ) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: sourceName,
          data: {
            ...(finalCompliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
            persons: finalPersons,
            person: finalPersons[0] || null,
            notFound: finalNoResult
          }
        });
      }
      return;
    }

    if (port) {
      port.postMessage({
        action: 'SEARCH_RESULT',
        searchId: searchId,
        source: sourceName,
        error: 'Timed out waiting for infolookupp.com results.'
      });
    }
  }

  // Owners as infolookupp.com renders them: `.cx-cards > .cx-card`, each holding
  // `.cx-name h3.value` (with a copy button inside that has to be stripped), `.cx-avatar`,
  // `.cx-age-badge` ("65 age (1961)") and a `.cx-addr-table` of `.cx-addr-row`s.
  function extractInfolookuppPersons() {
    const cards = Array.from(document.querySelectorAll('.cx-cards .cx-card, .cx-card'));
    if (!cards || cards.length === 0) return [];

    const persons = [];
    for (const card of cards) {
      let name = '';
      const nameEl = card.querySelector('.cx-name .value') || card.querySelector('.cx-name h3') || card.querySelector('.cx-name');
      if (nameEl) {
        const clone = nameEl.cloneNode(true);
        clone.querySelectorAll('button, svg').forEach((el) => el.remove());
        name = clone.textContent.trim();
      }

      let avatar = card.querySelector('.cx-avatar')?.textContent.trim() || '';
      if (!avatar && name) {
        avatar = name.slice(0, 2).toUpperCase();
      }
      const age = card.querySelector('.cx-age-badge')?.textContent.trim() || '';

      let bestAddress = null;
      let partialAddress = null;
      const allAddresses = [];
      const seenAddrKeys = new Set();
      const addrRows = Array.from(card.querySelectorAll('.cx-addr-table .cx-addr-row, .cx-addr-row'));

      for (const row of addrRows) {
        const street = cleanAddressField(row.querySelector('.cx-addr-street')?.textContent || '');
        const city = cleanAddressField(row.querySelector('.cx-addr-city')?.textContent || '');

        // The state and the ZIP are one "STATE / ZIP" column on the current build
        // (`.cx-addr-statezip`, e.g. "TX 77047") and two columns on the older one, so both are
        // read and the combined cell is split. A dash placeholder ("—") cleans to an empty
        // string, which is what keeps a street-only row street-only instead of
        // "8301 Tumbleweed Trl, Apt 3601, —, —".
        const stateZip = splitStateZip(row.querySelector('.cx-addr-statezip')?.textContent || '');
        const state = cleanAddressField(row.querySelector('.cx-addr-state')?.textContent || '') || stateZip.state;
        const zip = cleanAddressField(row.querySelector('.cx-addr-zip')?.textContent || '') || stateZip.zip;

        const cityStateZip = [city, state].filter(Boolean).join(', ') + (zip ? ` ${zip}` : '');
        const full = [street, cityStateZip].filter(Boolean).join(', ');

        if (!street && !city && !zip) continue;

        const dedupeKey = `${street.toLowerCase().replace(/[^a-z0-9]/g, '')}|${zip || city.toLowerCase()}`;
        if (seenAddrKeys.has(dedupeKey)) continue;
        seenAddrKeys.add(dedupeKey);

        const addrObj = { street, city, state, zip, full };
        allAddresses.push(addrObj);

        if (street && cityStateZip && !bestAddress) {
          bestAddress = addrObj;
        } else if (street && !bestAddress) {
          bestAddress = addrObj;
        } else if (cityStateZip && !partialAddress) {
          partialAddress = addrObj;
        }
      }

      const address = bestAddress || partialAddress;
      if (address && allAddresses.length === 0) {
        allAddresses.push(address);
      }

      if (name || age || address) {
        persons.push({ name, avatar, age, address, allAddresses });
      }
    }

    return persons;
  }

  function extractInfolookuppPerson() {
    const all = extractInfolookuppPersons();
    return all && all.length > 0 ? all[0] : null;
  }

  function extractInfolookuppCompliance() {
    let dnc = null, litigator = null, blacklist = null;
    const allElements = Array.from(document.querySelectorAll('div, tr, li, p, span, dt, dd'));

    for (const el of allElements) {
      const text = el.textContent.trim();
      if (!dnc && /^(DNC status|DNC|National DNC|State DNC)$/i.test(text)) dnc = getValueNear(el);
      if (!litigator && /^Litigator$/i.test(text)) litigator = getValueNear(el);
      if (!blacklist && /^Blacklist$/i.test(text)) blacklist = getValueNear(el);
    }

    const bodyText = document.body.innerText || '';
    if (!dnc) {
      const match = bodyText.match(/DNC(?:\s*status)?\s*[:\-]?\s*([^\n\r]+)/i);
      if (match && match[1] && !match[1].toLowerCase().includes('scrub')) dnc = cleanText(match[1]);
    }
    if (!litigator) {
      const match = bodyText.match(/Litigator\s*[:\-]?\s*([^\n\r]+)/i);
      if (match && match[1] && !match[1].toLowerCase().includes('scrub')) litigator = cleanText(match[1]);
    }
    if (!blacklist) {
      const match = bodyText.match(/Blacklist\s*[:\-]?\s*([^\n\r]+)/i);
      if (match && match[1] && !match[1].toLowerCase().includes('scrub')) blacklist = cleanText(match[1]);
    }

    if (dnc || litigator || blacklist) {
      return {
        dnc: formatInfolookuppComplianceValue(dnc || 'Clean'),
        litigator: formatInfolookuppComplianceValue(litigator || 'Clean'),
        blacklist: formatInfolookuppComplianceValue(blacklist || 'Clean')
      };
    }
    return null;
  }

  function formatInfolookuppComplianceValue(val) {
    if (!val) return 'Clean';
    const lower = val.toLowerCase().trim();
    if (lower === 'clean' || lower === 'not listed' || lower.includes('no record') || lower === 'pass' || lower === 'no') {
      return 'Clean';
    }
    if (lower.includes('federal') && lower.includes('state')) {
      return 'State & Federal DNC';
    }
    if (lower.includes('federal')) {
      return 'Federal DNC';
    }
    if (lower.includes('state')) {
      return 'State DNC';
    }
    if (lower === 'listed' || lower.includes('flagged') || lower === 'yes') {
      return 'Flagged';
    }
    return val.replace(/\b\w/g, c => c.toUpperCase());
  }

  function getValueNear(labelEl) {
    let next = labelEl.nextElementSibling;
    if (next && next.textContent.trim()) return cleanText(next.textContent.trim());

    const parent = labelEl.parentElement;
    if (parent) {
      const children = Array.from(parent.children);
      const idx = children.indexOf(labelEl);
      if (idx !== -1 && idx + 1 < children.length) {
        const val = children[idx + 1].textContent.trim();
        if (val) return cleanText(val);
      }
      if (parent.nextElementSibling && parent.nextElementSibling.textContent.trim()) {
        return cleanText(parent.nextElementSibling.textContent.trim());
      }
    }
    return null;
  }

  function cleanText(val) {
    if (!val) return '';
    let cleaned = val.replace(/^[•\s:\-]+/, '').trim();
    cleaned = cleaned.replace(/^(check-circle|info-circle|fas|fa|exclamation-circle)\s*/i, '');
    const firstLine = cleaned.split(/[\r\n]+/)[0].trim();
    return firstLine;
  }

  /* ═══════════════════════════════════════════════════════════════════════════════
     USPEOPLESEARCH.NET HELPERS  (Record 3)

     The phone box is `#input` with `#submit` beside it. The answer arrives in place:
     each compliance check fills a row under `#tcpa`, and the owners land in
     `#cards-wrap` as `.cx-card`s. While the lookup runs the page shows skeletons -
     the rows are there but empty and the cards carry no name - so nothing is read
     until the values themselves have arrived.
  ═══════════════════════════════════════════════════════════════════════════════ */

  // The whole answered text of the page. The site leaves the *previous* answer on screen while the
  // next lookup runs, so this is what tells a fresh answer from the one already there: the new answer
  // changes it, and a page that went empty (its skeletons) in between is proof enough on its own.
  function usPeopleAnswerStamp() {
    const text = (el) => (el ? (el.textContent || '').replace(/\s+/g, '') : '');
    return `${text(document.getElementById('tcpa'))}|${text(document.getElementById('cards-wrap'))}`;
  }

  // What the page is showing right now. `answered` is false while the lookup is still running: the
  // compliance rows exist but none of them carries a value, which is the skeleton state.
  function readUsPeopleDomState() {
    const compliance = extractUsPeopleCompliance();
    const persons = extractUsPeoplePersons();
    const bodyText = document.body ? document.body.innerText || '' : '';
    const noResultEl = document.querySelector(
      '#cx-ie.d-row.cx-prompt, p#cx-ie.cx-prompt, .d-row.cx-prompt'
    );
    const noResultText = noResultEl ? noResultEl.textContent || '' : '';
    const noResultPattern =
      /not found|no (?:records|results)(?: were)? found|invalid (?:phone )?number|please try a different number/i;

    return {
      compliance: compliance,
      persons: persons,
      answered: Boolean(compliance),
      noRecords:
        noResultPattern.test(noResultText) ||
        /no (?:records|results)(?: were)? found|invalid (?:phone )?number|please try a different number/i.test(bodyText)
    };
  }

  async function executeUsPeopleSearch(phone, searchId) {
    const start = Date.now();
    let phoneInput = null;

    // The search box, in the shapes this site has used: `#input` in the header form (with `#submit`
    // beside it), the same box by name, or a numeric box inside that form.
    while (Date.now() - start < 8000) {
      phoneInput =
        document.getElementById('input') ||
        document.querySelector('form input[name="input"]') ||
        document.querySelector('form input[type="tel"]') ||
        document.querySelector('input[inputmode="numeric"]');
      if (phoneInput) break;
      await sleep(150);
    }

    if (!phoneInput) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: sourceName,
          error: 'Phone input field was not found on uspeoplesearch.net.'
        });
      }
      return;
    }

    // Taken before the search is submitted: see usPeopleAnswerStamp.
    const stateBefore = readUsPeopleDomState();
    const stampBefore = usPeopleAnswerStamp();
    const noRecordsBefore = stateBefore.noRecords;

    const cleanDigits = phone.replace(/\D/g, '');
    phoneInput.focus();
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(phoneInput, cleanDigits);
    } else {
      phoneInput.value = cleanDigits;
    }
    phoneInput.dispatchEvent(new Event('input', { bubbles: true }));
    phoneInput.dispatchEvent(new Event('change', { bubbles: true }));
    phoneInput.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

    await sleep(60);

    const findSubmitButton = () =>
      document.getElementById('submit') ||
      document.querySelector('form button[type="submit"]') ||
      document.querySelector('button[type="submit"]') ||
      Array.from(document.querySelectorAll('button')).find((b) =>
        /search/i.test(`${b.textContent || ''} ${b.getAttribute('aria-label') || ''}`)
      ) ||
      null;

    let submitBtn = findSubmitButton();
    for (let attempt = 0; attempt < 10 && !submitBtn; attempt++) {
      await sleep(150);
      submitBtn = findSubmitButton();
    }

    // Enter as well as the click: the button is the documented way in, and a build that renders none
    // searches on Enter alone. The wait below is what reports a search that never ran.
    try {
      phoneInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    } catch (e) {}

    if (submitBtn) {
      submitBtn.click();
    } else {
      try {
        const form = phoneInput.form || (phoneInput.closest && phoneInput.closest('form'));
        if (form && typeof form.requestSubmit === 'function') {
          form.requestSubmit();
        }
      } catch (e) {}
    }

    const maxWaitResults = 45000;
    const searchStartTime = Date.now();
    let sawLoading = false;
    let stableResultKey = '';
    let stableResultAt = 0;

    await sleep(80);

    while (Date.now() - searchStartTime < maxWaitResults) {
      if (activeSearchId !== searchId) return;

      const state = readUsPeopleDomState();
      if (!state.answered && !state.noRecords) sawLoading = true;

      const freshAnswer = sawLoading || usPeopleAnswerStamp() !== stampBefore;
      if (state.noRecords && (!noRecordsBefore || freshAnswer)) {
        if (port) {
          port.postMessage({
            action: 'SEARCH_RESULT',
            searchId: searchId,
            source: sourceName,
            data: {
              ...(state.compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
              persons: [],
              person: null,
              notFound: true
            }
          });
        }
        return;
      }

      // The answer on screen is the new one: either the page went through its skeleton state after this
      // search was submitted, or the answered text is not the text that was there before it. That is
      // what keeps a previous lookup's answer from being reported as this one's.
      if (state.persons.length > 0 && freshAnswer) {
        const resultKey = JSON.stringify({ compliance: state.compliance, persons: state.persons });
        if (resultKey !== stableResultKey) {
          stableResultKey = resultKey;
          stableResultAt = Date.now();
        } else if (Date.now() - stableResultAt >= 1200) {
          if (port) {
            port.postMessage({
              action: 'SEARCH_RESULT',
              searchId: searchId,
              source: sourceName,
              data: {
                ...(state.compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
                persons: state.persons,
                person: state.persons[0] || null
              }
            });
          }
          return;
        }
      }

      await sleep(120);
    }

    // Nothing arrived in time. An answer that has landed by now is still worth reporting - a lookup
    // that took longer than the wait is not a failed one - while a page still showing its skeletons is
    // reported as the timeout it is, instead of being read as though the skeletons were the answer.
    const finalState = readUsPeopleDomState();
    const finalFreshAnswer = sawLoading || usPeopleAnswerStamp() !== stampBefore;
    if (finalState.persons.length > 0 && finalFreshAnswer) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: sourceName,
          data: {
            ...(finalState.compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
            persons: finalState.persons,
            person: finalState.persons[0] || null
          }
        });
      }
      return;
    }
    if (finalState.noRecords && (!noRecordsBefore || finalFreshAnswer)) {
      if (port) {
        port.postMessage({
          action: 'SEARCH_RESULT',
          searchId: searchId,
          source: sourceName,
          data: {
            ...(finalState.compliance || { dnc: 'Unknown', litigator: 'Unknown', blacklist: 'Unknown' }),
            persons: [],
            person: null,
            notFound: true
          }
        });
      }
      return;
    }

    if (port) {
      port.postMessage({
        action: 'SEARCH_RESULT',
        searchId: searchId,
        source: sourceName,
        error: 'Timed out waiting for uspeoplesearch.net results.'
      });
    }
  }

  // The compliance table of uspeoplesearch.net: one `.tcpa-row` per check, each holding a `.tcpa-label`
  // and the `.tcpa-value` the scrub fills in. That value carries `populated` once it has answered, and
  // the site's own verdict sits in the same attribute - `alert` for a hit, `safe` for a clear check -
  // which is read in preference to the wording ("Registered" / "Clean").
  //
  // Labels are matched with their whitespace removed: "DNC National", "DNC State" and "Litigator Owner"
  // each put half of their label in a <sub>, so the label reads "DNCNational" and "LitigatorOwner".
  function extractUsPeopleCompliance() {
    const rows = Array.from(document.querySelectorAll('#tcpa .tcpa-row, .tcpa .tcpa-row'));
    if (rows.length === 0) return null;

    const answers = Object.create(null);
    for (const row of rows) {
      const labelEl = row.querySelector('.tcpa-label');
      const valueEl = row.querySelector('.tcpa-value');
      if (!labelEl || !valueEl) continue;

      const key = cleanText(labelEl.textContent || '').replace(/\s+/g, '').toLowerCase();
      if (!key) continue;

      answers[key] = {
        value: cleanText(valueEl.textContent || ''),
        populated: valueEl.classList.contains('populated'),
        hit: valueEl.classList.contains('alert'),
        clear: valueEl.classList.contains('safe')
      };
    }

    const answer = (key) => {
      const row = answers[key];
      // An unpopulated row is the skeleton state, which is not an answer.
      if (!row || !row.populated || !row.value) return null;
      const hit = row.hit || (!row.clear && /regist|listed|flagged|dnc|yes/i.test(row.value));
      return { value: row.value, hit: hit };
    };

    const national = answer('dncnational');
    const state = answer('dncstate');
    const litigator = answer('litigator');
    const blacklist = answer('blacklist');
    const ownerLitigator = answer('litigatorowner');

    // Nothing has answered yet: the rows are on screen as skeletons, with empty values.
    if (!national && !state && !litigator && !blacklist) return null;

    return {
      dnc: usPeopleDncValue(national, state),
      // A litigator on the person's own row or on the owner's is a litigator on the record.
      litigator: usPeopleFlagValue(litigator, ownerLitigator),
      blacklist: usPeopleFlagValue(blacklist)
    };
  }

  // Registered on both lists is what the other two records report as "State & Federal DNC": the same
  // phone against the same two registers, so the same value, and the card colours it the same way.
  function usPeopleDncValue(national, state) {
    const onNational = Boolean(national && national.hit);
    const onState = Boolean(state && state.hit);
    if (onNational && onState) return 'State & Federal DNC';
    if (onNational) return 'Federal DNC';
    if (onState) return 'State DNC';
    return 'Clean';
  }

  // One flag per card, from the rows that belong to it. A check with no row, or a row that never
  // answered, reads as clear - which is what the other two records do with the same missing answer.
  function usPeopleFlagValue(...rows) {
    return rows.some((row) => row && row.hit) ? 'Flagged' : 'Clean';
  }

  // The owners as uspeoplesearch.net renders them: `#cards-wrap > .cx-card`, each carrying the name and
  // age in `.cx-basic`, the addresses in `.cx-addresses .cx-address` (the first row is "LIVES AT" and
  // the rest "LIVED AT", each with a `.cx-address-col` per part), the relatives in `.cx-misc
  // .cx-related` and the birth year in `.cx-misc .cx-dob`.
  //
  // A card with no name is one of the loading skeletons and is skipped, which is what keeps a half-drawn
  // answer from being read as a person.
  function extractUsPeoplePersons() {
    const cards = Array.from(document.querySelectorAll('#cards-wrap > .cx-card, .cx-info .cx-card'));
    if (cards.length === 0) return [];

    const persons = [];
    for (const card of cards) {
      let name = '';
      const nameEl = card.querySelector('.cx-name .value') || card.querySelector('.cx-name h3');
      if (nameEl) {
        const clone = nameEl.cloneNode(true);
        clone.querySelectorAll('button, svg').forEach((el) => el.remove());
        name = cleanText(clone.textContent || '');
      }
      if (!name) continue;

      // The card shows the age and the birth year in separate columns; the card format the widget reads
      // is the one the other records produce, "84 yrs (1942)".
      const ageValue = cleanText((card.querySelector('.cx-age .value') || {}).textContent || '');
      const dobValue = cleanText((card.querySelector('.cx-dob .value') || {}).textContent || '');
      const age = ageValue ? (dobValue ? `${ageValue} yrs (${dobValue})` : `${ageValue} yrs`) : '';

      let bestAddress = null;
      const allAddresses = [];
      for (const row of Array.from(card.querySelectorAll('.cx-addresses .cx-address, .cx-address'))) {
        const street = cleanAddressField(readUsPeopleAddressCol(row, 'home'));
        const city = cleanAddressField(readUsPeopleAddressCol(row, 'city'));
        // The state column holds the full name ("Ohio") on this site, which every lookup downstream
        // already accepts (the same shape the other record produces).
        const state = cleanAddressField(readUsPeopleAddressCol(row, 'state'));
        const zip = cleanAddressField(readUsPeopleAddressCol(row, 'zip'));
        if (!street) continue;

        const full = [street, [city, state].filter(Boolean).join(', '), zip]
          .filter(Boolean)
          .join(', ')
          // The state and the ZIP are one field on the card ("Cincinnati, Ohio 45236"), so the comma
          // between them goes - whichever way the state is written, "OH" or "Ohio".
          .replace(/,\s*([A-Za-z]{2,}),\s*(\d{5})\b/, ', $1 $2');

        const address = { street: street, city: city, state: state, zip: zip, full: full };
        // "LIVES AT" is the current address and is the one every action runs on; the "LIVED AT" rows
        // stay in the history beside it.
        const label = cleanText((row.querySelector('.cx-address-col.home .label') || {}).textContent || '');
        if (!bestAddress && /^lives/i.test(label)) bestAddress = address;
        allAddresses.push(address);
      }
      if (!bestAddress) bestAddress = allAddresses[0] || null;

      const related = Array.from(card.querySelectorAll('.cx-related .value.relation, .cx-related .relation'))
        .map((el) => cleanText(el.textContent || ''))
        .filter((relative) => relative && !/^not present$/i.test(relative));

      persons.push({
        name: name,
        avatar: name.slice(0, 2).toUpperCase(),
        age: age,
        address: bestAddress,
        allAddresses: allAddresses,
        related: related
      });
    }

    return persons;
  }

  // One column of an owner's address row: the street ("home"), city, state or ZIP.
  function readUsPeopleAddressCol(row, col) {
    const el =
      row.querySelector(`.cx-address-col.${col} .value`) ||
      row.querySelector(`.cx-address-col.${col} h4.value`) ||
      row.querySelector(`.${col} .value`);
    return el ? el.textContent || '' : '';
  }
})();
